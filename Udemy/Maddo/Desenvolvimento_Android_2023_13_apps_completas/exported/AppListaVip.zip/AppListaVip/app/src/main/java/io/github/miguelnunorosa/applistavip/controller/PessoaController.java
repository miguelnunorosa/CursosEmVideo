package io.github.miguelnunorosa.applistavip.controller;

public class PessoaController {
}
